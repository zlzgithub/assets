import csv
import hashlib
import json
import os

import requests
from django.conf import settings
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

from conf.logger import monitor_logger
from utils.db.mongo_ops import MongoOps, JSONEncoder
from utils.decorators import admin_auth

mongo_monitor = MongoOps(
    settings.MONGODB_HOST,
    settings.MONGODB_PORT,
    settings.RECORD_DB,
    "monitor",
    settings.MONGODB_USER,
    settings.MONGODB_PASS
)

mongo_monitor_settings = MongoOps(
        settings.MONGODB_HOST,
        settings.MONGODB_PORT,
        settings.RECORD_DB,
        "monitor_settings",
        settings.MONGODB_USER,
        settings.MONGODB_PASS
    )


@admin_auth
def api_chart_data(request):
    monitor_logger.info("api_chart_data ...")
    data = []
    for ds in ["1", "2", "3", "4"]:
        data.append(do_api_chart_data(request, ds=ds))

    monitor_logger.info("api_chart_data ... ok")
    return JsonResponse({"code": 200, "data": data})


@admin_auth
def do_api_chart_data(request, ds="1"):
    """
    图表数据接口
    :param request:
    :param ds:
    :return:
    """
    monitor_logger.info("do api_chart_data ... " + ds)
    db_data, _ = mongo_monitor.find({"source": ds})[:30]
    x_data = []
    y_data_dict = {}
    try:
        d_keys = [e for e in db_data[0]["data"].keys() if e not in ["source", "date"]]
        # d_keys = ["high", "medium", "low"]
        for d in db_data:
            x_data.append(d["data"].get("date"))
            for dk in d_keys:
                y_data_dict.setdefault(dk, []).append(d["data"].get(dk))

        chart_data = {
            "x_data": x_data,
            "y_data": [{"name": k, "value": v} for k, v in y_data_dict.items()]
        }
        monitor_logger.info(chart_data)
        monitor_logger.info("do api_chart_data ... ok " + ds)
        # return JsonResponse({"code": 200, "data": chart_data})
        return {"code": 200, "data": chart_data}
    except Exception as e:
        monitor_logger.error(str(e))
        # return JsonResponse({"code": 500, "data": {}})
        return {"code": 500, "data": {}}


@admin_auth
def monitor_data(request):
    """
    显示数据列表
    :param request:
    :return:
    """
    monitor_logger.info("monitor data ...")
    return render(request, 'monitor/monitor_data.html')


@admin_auth
def get_monitor_data(request, ds):
    """
    :param request:
    :param ds: 0 已注册的  1 现存的
    :return:
    """
    monitor_logger.info("get_monitor_data ...")
    draw = int(request.GET.get('draw'))
    start = int(request.GET.get('start'))
    length = int(request.GET.get('length'))
    # start_time = request.GET.get('startTime')
    # end_time = request.GET.get('endTime')
    s_name = request.GET.get('s_name')
    order_col = request.GET.get('order[0][column]')
    order_col_name = request.GET.get('columns[{}][data]'.format(order_col))
    order_type = 1 if request.GET.get('order[0][dir]') == 'asc' else -1
    dc = request.GET.get('dc')
    # search_options = {"ds": int(ds)}
    search_options = {}
    try:
        if s_name:
            # search_options.update({"source": {"$regex": f".*{s_name}.*"}})
            search_options.update({"source": s_name})
        if dc:
            search_options.update({"dc": dc})

        searched_data, _ = mongo_monitor.find(search_options,
                                              start,
                                              length,
                                              sort_key=order_col_name,
                                              sort_method=order_type)
        _, count = mongo_monitor.find(search_options)
        dic = {
            'draw': draw,
            'recordsFiltered': count,
            'recordsTotal': count,
            'data': searched_data
        }
        monitor_logger.info(search_options)
        monitor_logger.info(searched_data)
        monitor_logger.info("get_monitor_data ... ok")
        return HttpResponse(json.dumps(dic, cls=JSONEncoder), content_type='application/json')
    except Exception as e:
        return JsonResponse({'code': 500, 'data': [], 'msg': u'获取失败：{}'.format(e)})


def chk_monitor_settings(monitor_url, monitor_token, monitor_dc):
    url_services = os.path.join(monitor_url, "v1/internal/ui/services?dc={}".format(monitor_dc))
    headers = {"X-Consul-Token": monitor_token}
    resp = requests.get(url_services, headers=headers)
    if 200 == resp.status_code:
        # return JsonResponse({'code': 200, 'data': 1, 'msg': u'OK'})
        return True
    else:
        # return JsonResponse({'code': 500, 'data': 0, 'msg': u'Failed'})
        return False


def get_monitor_settings(dc='dc1'):
    monitor_logger.info("[get_monitor_settings] ...")
    res = mongo_monitor_settings.find_one({'monitor_dc': dc})
    monitor_logger.info("res is:")
    monitor_logger.info(res)
    if res:
        # monitor_dc = res["monitor_dc"]
        monitor_url = res["monitor_url"]
        monitor_token = res["monitor_token"]
        return monitor_url, monitor_token
    else:
        return None, None


@admin_auth
def api_write_monitor_settings(request):
    try:
        req_body = json.loads(request.body)
        monitor_logger.info("[api_write_monitor_settings] request body:")
        monitor_logger.info(req_body)
        monitor_dc = req_body.get('monitor_dc')
        monitor_url = req_body.get('monitor_url')
        monitor_token = req_body.get('monitor_token')
        monitor_settings_json = req_body.get('monitor_settings_json')

        # check
        if chk_monitor_settings(monitor_url, monitor_token, monitor_dc):
            new_settings = {
                "monitor_dc": monitor_dc,
                "monitor_url": monitor_url,
                "monitor_token": monitor_token
            }
            mongo_monitor_settings.update_many(pk={}, sk={"$set": new_settings})
            return JsonResponse({'code': 200, 'data': 1, 'msg': u'已保存'})
        else:
            return JsonResponse({'code': 500, 'data': 0, 'msg': u'访问失败，不予保存'})
    except Exception as e:
        return JsonResponse({'code': 500, 'data': None, 'msg': u'设置失败: {}'.format(str(e))})


@admin_auth
def api_read_monitor_settings(request):
    res = mongo_monitor_settings.find_one({})
    monitor_logger.info("[api_read_monitor_settings] res is: ")
    monitor_logger.info(res)
    del res["_id"]
    res["monitor_token"] = "************"
    # monitor_settings = res
    # monitor_settings
    if res:
        return JsonResponse({'code': 200, 'data': res, 'msg': 'OK'})
    else:
        return JsonResponse({'code': 500, 'data': res, 'msg': u'获取失败'})


@admin_auth
def api_update_monitor_data(request):
    monitor_logger.info("api_update_monitor_data ...")
    try:
        # 模拟写入数据
        csv_file = os.path.join(settings.BASE_DIR, 'monitor', 'search_data0.csv')
        with open(csv_file, 'r') as f:
            # csv_reader = csv.reader(f, delimiter=',', quotechar='')
            csv_reader = csv.DictReader(f)
            mongo_data = []
            for row in csv_reader:
                data = dict(zip(row.keys(), [int(v) if i > 0 else v for i, v in enumerate(row.values())]))
                mongo_data.append({"source": row.get("source"), "data": data})
            mongo_monitor.delete({})
            mongo_monitor.insert_many(mongo_data)
    except FileNotFoundError as e:
        monitor_logger.error(str(e))
    except Exception as e2:
        monitor_logger.error(str(e2))
    else:
        monitor_logger.info("api_update_monitor_data ... end")

    return JsonResponse({'code': 200, 'msg': 'OK'})


@admin_auth
def api_update_monitor_data000(request):
    """
    涉及两个视图的数据，一个是 应注册的， 一个是 实际注册的
    ，更新实际注册的，并对比标记 应注册的 丢失与否
    :param request:
    :return:
    """
    # 获取更新前的数据，以作对比
    # service_data0, count = mongo.find({"ds": 0})

    # 获取最新数据，对比，标记状态
    dc = request.GET.get("dc") or "dc1"
    monitor_url, monitor_token = get_monitor_settings(dc=dc)
    headers = {"X-Consul-Token": monitor_token}
    url_services = os.path.join(monitor_url, "v1/internal/ui/services?dc={}".format(dc))
    monitor_logger.info("url:")
    monitor_logger.info(url_services)
    resp = requests.get(url_services, headers=headers)
    if 200 == resp.status_code:
        c_data = json.loads(resp.content)
        # mongo.insert_many(c_data)
        # 更新（包括新增）
        for c in c_data:
            c["ds"] = 1
            # mongo.update_insert_one_by_pk_sk(c, pk=["ds", "Name"])
        mongo_monitor.delete({"ds": 1})
        mongo_monitor.insert_many(c_data)

        # 标记已注册的同名service为正常, 不存在该已注册项则新增一条已注册, 如果存在多余未能匹配的则标记为Lost
        mongo_monitor.update_many(pk={"ds": 0}, sk={"$set": {"Status": "Lost",
                                                     "ChecksPassing": 0, "ChecksWarning": 0, "ChecksCritical": 0}})
        for c in c_data:
            c["ds"] = 0
            del c["_id"]
            mongo_monitor.update_insert_one_by_pk_sk(c, pk=["ds", "Name"],
                                                    sk={"$set": {"Status": "OK"},
                                                 "$set_if_not": {"Status": "New"}})
        return JsonResponse({"code": 200, "msg": "更新完毕"})
    else:
        return JsonResponse({"code": 500, "msg": "更新失败"})


@admin_auth
def get_service_info(request):
    """
    前端分页即可
    :param request:
    :return:
    """
    monitor_logger.info("[get_service_info]")
    if request.method == 'GET':
        s_name = request.GET.get('s_name')
        dc = request.GET.get('dc') or "dc1"
    if request.method == 'POST':
        s_name = request.POST.get('s_name')
        dc = request.POST.get('dc') or "dc1"
    monitor_logger.info("s_name={}, dc ={}".format(s_name, dc))

    monitor_url, monitor_token = get_monitor_settings(dc=dc)
    headers = {"X-Consul-Token": monitor_token}
    url_service = os.path.join(monitor_url, "v1/health/service/{}?dc={}".format(s_name, dc))
    resp = requests.get(url_service, headers=headers)

    monitor_logger.info("[get_service_info] resp code:" + str(resp.status_code))
    if 200 == resp.status_code:
        c_data = json.loads(resp.content)
        monitor_logger.info("c_data")
        monitor_logger.info(c_data)
        # get status
        node_check_ok = 1
        node_check_bad = 0
        service_check_ok = 0
        service_check_bad = 0
        # total_node_check = 1
        # total_service_check = 0
        for c in c_data:
            if "Checks" in c:
                if len(c["Checks"]) >= 1:
                    node_check_ok = 1 if c["Checks"][0]["Status"] == "passing" else 0
                    node_check_bad = 1 if c["Checks"][0]["Status"] != "passing" else 0
                if len(c["Checks"]) == 2:
                    service_check_ok = 1 if c["Checks"][1]["Status"] == "passing" else 0
                    service_check_bad = 1 if c["Checks"][1]["Status"] != "passing" else 0
            c["Status"] = {
                "NodeCheckPassing": node_check_ok,
                "NodeCheckNotPassing": node_check_bad,
                "ServiceCheckPassing": service_check_ok,
                "ServiceCheckNotPassing": service_check_bad
            }
            # total_node_check += node_check
            # total_service_check += service_check
        # c_data.append({"TotalNodeCheck": total_node_check})
        # c_data.append({"TotalServiceCheck": total_service_check})
        return JsonResponse({'code': 200, 'data': c_data, 'msg': u'获取成功'}, encoder=JSONEncoder)
    else:
        return JsonResponse({'code': 500, 'data': None, 'msg': u'获取失败，{}'.format(resp.content)})


@admin_auth
def del_service_definition(request):
    try:
        monitor_logger.info("del_service_definition")
        s_name = None
        md5 = None
        s_id = None
        if request.method == "POST":
            s_id = request.POST.get('s_id')
            s_name = request.POST.get('s_name')
            md5 = request.POST.get('md5')
        if request.method == "GET":
            s_id = request.GET.get('s_id')
            s_name = request.GET.get('s_name')
            md5 = request.GET.get('md5')

        if not s_name:
            return JsonResponse({'code': 500, 'msg': u'参数错误'})

        res = mongo_monitor.find_one({"ds": 2, "Name": s_name})
        if md5:
            md5_list = res["md5_list"]
            if md5 in md5_list:
                md5_list.remove(md5)

                definitions = res["definitions"]
                for d in definitions:
                    if d.get("md5") == md5:
                        definitions.remove(d)
            del res["_id"]
            mongo_monitor.update_insert_one_by_pk_sk(res, pk={"ds": 2, "Name": s_name},
                                                    sk={"$set": {"Status": "Changed"},
                                                 "$set_if_not": {"Status": "New"}})
        elif s_id:
            definitions = res["definitions"]
            md5_list = res["md5_list"]
            for d in definitions:
                if d.get("ID") == s_id:
                    definitions.remove(d)
                    md5_list.remove(d.get("md5"))
        else:
            mongo_monitor.delete({"ds": 2, "Name": s_name})
        return JsonResponse({'code': 200, 'msg': 'OK'})
    except Exception as e:
        monitor_logger.info(str(e))
        return JsonResponse({'code': 500, 'msg': 'error'})


@admin_auth
def deregister_service(request):
    monitor_logger.info("[deregister_service]")
    if request.method == "POST":
        s_id = request.POST.get('s_id')
        s_name = request.POST.get('s_name')
        ds = int(request.POST.get('ds') or "1")
    if request.method == "GET":
        s_id = request.GET.get('s_id')
        s_name = request.GET.get('s_name')
        ds = int(request.GET.get('ds') or "1")
    dc = request.GET.get('dc') or "dc1"
    headers = {
        "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
    }

    if 0 == ds:
        # 删除记录，一个服务(Name)一个记录，不涉及ID
        monitor_logger.info("----------------------------001")
        if not s_name:
            return JsonResponse({'code': 500, 'msg': u'参数错误'})
        else:
            res = mongo_monitor.delete({"ds": 0, "Name": s_name})
            return JsonResponse({'code': 200,
                                 'msg': u'共删除了{}条记录<br>Name: {}'.format(
                                     res.deleted_count, s_name)}, encoder=JSONEncoder)

    monitor_url, monitor_token = get_monitor_settings(dc=dc)
    headers = {"X-Consul-Token": monitor_token}
    url_tmpl = os.path.join(monitor_url, "v1/agent/service/deregister/{id}")
    if s_id:
        monitor_logger.info("----------------------------002")
        resp = requests.put(url_tmpl.format(id=s_id), headers=headers)
        if 200 == resp.status_code:
            update_after_deregister(s_name, n_succ=1, dc=dc)
            return JsonResponse({'code': 200, 'msg': u'注销成功'}, encoder=JSONEncoder)
        else:
            update_after_deregister(s_name, n_succ=0, dc=dc)
            return JsonResponse({'code': 500, 'msg': u'注销失败，{}'.format(resp.content)})
    elif s_name:
        monitor_logger.info("----------------------------003")
        s_ids = []
        res = get_service_info(request)
        resp = json.loads(res.content)
        # monitor_logger.info(json.dumps(resp, indent=4))
        if resp["code"] == 200:
            monitor_logger.info("200 ...")
            for c in resp["data"]:
                monitor_logger.info("for c: {}".format(json.dumps(c)))
                s_ids.append(c["Service"]["ID"])

        monitor_logger.info("s_ids is:")
        monitor_logger.info(", ".join(s_ids))
        is_all_succ = True
        msg = []
        id_succ = []
        id_failed = []
        for id in s_ids:
            resp = requests.put(url_tmpl.format(id=id), headers=headers)
            if resp.status_code != 200:
                is_all_succ = False
                id_failed.append(id)
                msg.append("id: {} failed".format(id))
            else:
                id_succ.append(id)
                msg.append("id: {} succeed".format(id))
        update_after_deregister(s_name, n_succ=len(id_succ), dc=dc)
        if is_all_succ:
            mongo_monitor.delete({"ds": 1, "Name": s_name})
            return JsonResponse({'code': 200, 'msg': u'注销成功，并已删除{}的记录'.format(s_name)}, encoder=JSONEncoder)
        else:
            return JsonResponse({'code': 500, 'msg': "<br>".join(msg)})
