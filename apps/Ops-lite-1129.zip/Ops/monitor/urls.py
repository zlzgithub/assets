"""Ops URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path, include, re_path
from django.views.static import serve
from django.conf import settings
from monitor import views


urlpatterns = [
    path(r'monitor_data/', views.monitor_data, name='monitor_data'),
    re_path(r'get_monitor_data/(?P<ds>[0-9]+)/', views.get_monitor_data, name='get_monitor_data'),
    path(r'read_monitor_settings/', views.api_read_monitor_settings, name='read_monitor_settings'),
    path(r'write_monitor_settings/', views.api_write_monitor_settings, name='write_monitor_settings'),
    path(r'update_monitor_data/', views.api_update_monitor_data, name='update_monitor_data'),
    path(r'api_chart_data/', views.api_chart_data, name='api_chart_data'),
    # re_path(r'api_chart_data/(?P<ds>[0-9]+)/', views.api_chart_data, name='api_chart_data'),
]
