import csv


if __name__ == '__main__':
    with open('search_data0.csv', 'r') as f:
        # csv_reader = csv.reader(f, delimiter=',', quotechar='')
        csv_reader = csv.DictReader(f)
        for row in csv_reader:
            row_info = ','.join(row.values())
            print(row_info)
