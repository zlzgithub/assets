# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name：      tasks
   Description:
   Author:          Administrator
   date：           2018-07-16
-------------------------------------------------
   Change Activity:
                    2018-07-16:
-------------------------------------------------
"""
from __future__ import absolute_import, unicode_literals
from Ops.celery import app
# from utils.wx_alert import WxApi
from utils.db.mongo_ops import MongoOps
from Ops import settings
from conf.logger import user_logger
import datetime


@app.task
def test_celery(filename, some):
    with open(filename, 'a+') as f:
        f.write(some)


@app.task
def test_add(a, b):
    user_logger.info("000 test_add ...")
    return int(a) + int(b)


@app.task
def remove_system_log(days=90):
    deadline = datetime.datetime.now() - datetime.timedelta(days)

    m = MongoOps(settings.MONGODB_HOST, settings.MONGODB_PORT, settings.RECORD_DB, settings.RECORD_COLL,
                 settings.MONGODB_USER, settings.MONGODB_PASS)
    rs, _ = m.find({"datetime": {"$lt": deadline}})
    m.delete({"datetime": {"$lt": deadline}}, del_all=True)
