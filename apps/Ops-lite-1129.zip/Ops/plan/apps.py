from django.apps import AppConfig


class PlanConfig(AppConfig):
    name = 'plan'
