from django.urls import path, include
from rest_framework import routers
from api import views

router = routers.DefaultRouter()
router.register(r'periodic_task', views.PeriodicTaskViewSet)
router.register(r'website', views.WebSiteViewSet)

urlpatterns = [
    path(r'', include(router.urls)),
    path(r'api/', include('rest_framework.urls', namespace='rest_framework')),
]
