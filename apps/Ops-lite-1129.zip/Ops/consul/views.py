import hashlib
import json
import os

import requests
from django.conf import settings
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

from conf.logger import consul_logger
from utils.db.mongo_ops import MongoOps, JSONEncoder
from utils.decorators import admin_auth

mongo_consul = MongoOps(
    settings.MONGODB_HOST,
    settings.MONGODB_PORT,
    settings.RECORD_DB,
    "consul",
    settings.MONGODB_USER,
    settings.MONGODB_PASS
)

mongo_consul_settings = MongoOps(
        settings.MONGODB_HOST,
        settings.MONGODB_PORT,
        settings.RECORD_DB,
        "consul_settings",
        settings.MONGODB_USER,
        settings.MONGODB_PASS
    )


@admin_auth
def consul_data(request):
    return render(request, 'consul/consul_data.html')


@admin_auth
def consul_registered(request):
    return render(request, 'consul/consul_registered.html')


@admin_auth
def service_definition(request):
    consul_logger.info("[service_definition] ...")
    s_name = request.GET.get("s_name")
    dc = request.GET.get("dc") or "dc1"
    consul_logger.info("s_name: " + s_name)
    ds = request.GET.get("ds")
    return render(request, 'consul/service_definition.html', locals())


@admin_auth
def service_info(request):
    consul_logger.info("[service_info] ...")
    s_name = request.GET.get("s_name")
    dc = request.GET.get("dc") or "dc1"
    consul_logger.info("s_name: " + s_name)
    ds = request.GET.get("ds")
    return render(request, 'consul/service_info.html', locals())


def chk_consul_settings(consul_url, consul_token, consul_dc):
    url_services = os.path.join(consul_url, "v1/internal/ui/services?dc={}".format(consul_dc))
    headers = {"X-Consul-Token": consul_token}
    resp = requests.get(url_services, headers=headers)
    if 200 == resp.status_code:
        # return JsonResponse({'code': 200, 'data': 1, 'msg': u'OK'})
        return True
    else:
        # return JsonResponse({'code': 500, 'data': 0, 'msg': u'Failed'})
        return False


def get_consul_settings(dc='dc1'):
    consul_logger.info("[get_consul_settings] ...")
    res = mongo_consul_settings.find_one({'consul_dc': dc})
    consul_logger.info("res is:")
    consul_logger.info(res)
    if res:
        # consul_dc = res["consul_dc"]
        consul_url = res["consul_url"]
        consul_token = res["consul_token"]
        return consul_url, consul_token
    else:
        return None, None


@admin_auth
def api_write_consul_settings(request):
    try:
        req_body = json.loads(request.body)
        consul_logger.info("[api_write_consul_settings] request body:")
        consul_logger.info(req_body)
        consul_dc = req_body.get('consul_dc')
        consul_url = req_body.get('consul_url')
        consul_token = req_body.get('consul_token')
        consul_settings_json = req_body.get('consul_settings_json')

        # check
        if chk_consul_settings(consul_url, consul_token, consul_dc):
            new_settings = {
                "consul_dc": consul_dc,
                "consul_url": consul_url,
                "consul_token": consul_token
            }
            mongo_consul_settings.update_many(pk={}, sk={"$set": new_settings})
            return JsonResponse({'code': 200, 'data': 1, 'msg': u'已保存'})
        else:
            return JsonResponse({'code': 500, 'data': 0, 'msg': u'访问失败，不予保存'})
    except Exception as e:
        return JsonResponse({'code': 500, 'data': None, 'msg': u'设置失败: {}'.format(str(e))})


@admin_auth
def api_read_consul_settings(request):
    res = mongo_consul_settings.find_one({})
    consul_logger.info("[api_read_consul_settings] res is: ")
    consul_logger.info(res)
    del res["_id"]
    res["consul_token"] = "************"
    # consul_settings = res
    # consul_settings
    if res:
        return JsonResponse({'code': 200, 'data': res, 'msg': 'OK'})
    else:
        return JsonResponse({'code': 500, 'data': res, 'msg': u'获取失败'})


@admin_auth
def get_consul_data(request, ds):
    """
    :param request:
    :param ds: 0 已注册的  1 现存的
    :return:
    """
    draw = int(request.GET.get('draw'))  # 记录操作次數
    start = int(request.GET.get('start'))  # 起始位置
    length = int(request.GET.get('length'))  # 每页长度
    # start_time = request.GET.get('startTime')
    # end_time = request.GET.get('endTime')
    s_name = request.GET.get('s_name')
    order_col = request.GET.get('order[0][column]')
    order_col_name = request.GET.get('columns[{}][data]'.format(order_col))
    order_type = 1 if request.GET.get('order[0][dir]') == 'asc' else -1
    dc = request.GET.get('dc')
    search_options = {"ds": int(ds)}
    try:
        if s_name:
            search_options.update({"Name": {"$regex": f".*{s_name}.*"}})
        if dc:
            search_options.update({"dc": dc})
        # if start_time and end_time:
        #     start_time = datetime.datetime.strptime(start_time, '%Y-%m-%d')
        #     end_time = datetime.datetime.strptime(end_time, '%Y-%m-%d') + datetime.timedelta(1)
        #     search_options.update({"datetime": {"$gt": start_time, "$lt": end_time}})

        searched_data, _ = mongo_consul.find(search_options, start, length, sort_key=order_col_name, sort_method=order_type)
        _, count = mongo_consul.find(search_options)
        # consul_logger.info("order_type:" + str(order_type))
        # consul_logger.info("order_col:" + str(order_col))
        # consul_logger.info("order_col_name:" + str(order_col_name))
        dic = {
            'draw': draw,
            'recordsFiltered': count,
            'recordsTotal': count,
            'data': searched_data
        }
        return HttpResponse(json.dumps(dic, cls=JSONEncoder), content_type='application/json')
    except Exception as e:
        return JsonResponse({'code': 500, 'data': [], 'msg': u'获取失败：{}'.format(e)})


@admin_auth
def register_service(request):
    try:
        req_body = json.loads(request.body)
        consul_logger.info("[register_service] request body:")
        consul_logger.info(req_body)
        s_id = req_body.get('s_id')
        dc = req_body.get('dc')
        s_name = req_body.get('s_name')
        s_tags = req_body.get('s_tags').split(",")
        if ":" in req_body.get('s_ip_port'):
            ip, port = req_body.get('s_ip_port').split(":")
        else:
            ip = req_body.get('s_ip_port')
            port = 80
        s_extra = req_body.get('s_extra')
        payload = {
            "ID": s_id,
            "Name": s_name,
            "Tags": s_tags,
            "Address": ip,
            "Port": int(port)
        }

        if s_extra:
            d_extra = json.loads('{{{d}}}'.format(d=s_extra))
            payload.update(d_extra)
            if not dc and 'dc' in d_extra['Meta']:
                dc = d_extra['Meta']['dc']

        dc = dc or 'dc1'
        # consul_logger.info("final payload:")
        # consul_logger.info(payload)
        consul_url, consul_token = get_consul_settings(dc=dc)
        url_reg = os.path.join(consul_url, "v1/agent/service/register")
        headers = {"X-Consul-Token": consul_token}
        resp = requests.put(url_reg, data=json.dumps(payload), headers=headers)
        if resp.status_code != 200:
            return JsonResponse({"code": 500, "msg": str(resp.content)})
        else:
            # return update_consul_data(request)  # 请求转发
            return update_after_register(s_name, dc=dc, payload=payload)
    except Exception as e:
        consul_logger.info("exception:")
        consul_logger.error(str(e))
        return JsonResponse({"code": 500, "msg": str(e)})


@admin_auth
def apply_definition(request):
    try:
        consul_logger.info("[apply_definition] ...")
        payload = json.loads(request.body)
        consul_logger.info(json.dumps(payload))
        del payload['md5']
        dc = payload.get('dc') if 'dc' in payload else 'dc1'
        s_name = payload.get('Name')
        # consul_logger.info("applying payload:")
        # consul_logger.info(payload)
        consul_url, consul_token = get_consul_settings(dc=dc)
        url_reg = os.path.join(consul_url, "v1/agent/service/register")
        headers = {"X-Consul-Token": consul_token}
        resp = requests.put(url_reg, data=json.dumps(payload), headers=headers)
        if resp.status_code != 200:
            return JsonResponse({"code": 500, "msg": str(resp.content)})
        else:
            return update_after_register(s_name, dc=dc, payload=payload)
    except Exception as e:
        consul_logger.info("applying payload exception:")
        consul_logger.error(str(e))
        return JsonResponse({"code": 500, "msg": str(e)})


def update_new_service_data(s_name, dc="dc1"):
    mongo_consul.delete({"ds": 1, "Name": s_name})
    consul_url, consul_token = get_consul_settings(dc=dc)
    url_services = os.path.join(consul_url, "v1/internal/ui/services?dc={}".format(dc))
    headers = {"X-Consul-Token": consul_token}
    resp = requests.get(url_services, headers=headers)
    if 200 == resp.status_code:
        c_data = json.loads(resp.content)
        for c in c_data:
            if s_name == c["Name"]:
                consul_logger.info("s_name == c.Name, " + s_name)
                c["ds"] = 1
                c["dc"] = dc
                c["Status"] = "Changed"
                mongo_consul.insert_one(c)
                c["ds"] = 0
                del c["_id"]
                mongo_consul.update_insert_one_by_pk_sk(c, pk={"ds": 0, "Name": s_name},
                                                        sk={"$set": {"Status": "Changed +1"},
                                                     "$set_if_not": {"Status": "New"}})
                break
        return JsonResponse({"code": 200, "msg": "update_service_data ok"})
    else:
        return JsonResponse({"code": 500, "msg": "update_service_data failed"})


def update_de_service_data(s_name, n_succ, dc="dc1"):
    """
    TODO 待进一步修改 0422 24:00
    :param s_name:
    :param n_succ:
    :param dc:
    :return:
    """
    consul_logger.info("[update_de_service_data] ...")
    mongo_consul.delete({"ds": 1, "Name": s_name})
    consul_url, consul_token = get_consul_settings(dc=dc)
    headers = {"X-Consul-Token": consul_token}
    url_service = os.path.join(consul_url, "v1/health/service/{}?dc={}".format(s_name, dc))
    resp = requests.get(url_service, headers=headers)
    if 200 == resp.status_code:
        consul_logger.info("200 ...")
        if resp.content == b'[]':
            consul_logger.info("empty ...")
            mongo_consul.update_many(pk={"ds": 0, "Name": s_name},
                                     sk={"$set": {"Status": "Lost -{}".format(n_succ) if n_succ > 0 else "Lost",
                                           "ChecksPassing": 0, "ChecksWarning": 0, "ChecksCritical": 0}})
            return JsonResponse({"code": 200, "msg": "update_service_data ok"})
        else:
            # 服务还没有完全删除的情况
            consul_logger.info("not empty ...")
            consul_logger.info(resp.content)
            consul_url, consul_token = get_consul_settings(dc=dc)
            headers = {"X-Consul-Token": consul_token}
            url_services = os.path.join(consul_url, "v1/internal/ui/services?dc={}".format(dc))
            resp = requests.get(url_services, headers=headers)
            if 200 == resp.status_code:
                c_data = json.loads(resp.content)
                # 找到对应的Service，以便直接获取其checks数据
                for c in c_data:
                    if s_name == c["Name"]:
                        consul_logger.info("s_name == c.Name, " + s_name)
                        # 更新ds1
                        c["ds"] = 1
                        c["dc"] = dc
                        c["Status"] = "Changed"
                        mongo_consul.insert_one(c)
                        # 更新ds0
                        del c["_id"]
                        c["ds"] = 0
                        c["Status"] = "Changed -{}".format(n_succ) if n_succ > 0 else "OK"
                        mongo_consul.update_many(pk={"ds": 0, "Name": s_name}, sk={"$set": c})
                        break
                # stat = "Changed -{}".format(n_succ) if n_succ > 0 else "OK"
                # mongo.update_many(pk={"ds": 0, "Name": s_name}, sk={"$set": {"Status": stat}})
                return JsonResponse({"code": 200, "msg": "update_service_data ok"})
    return JsonResponse({"code": 500, "msg": "update_service_data failed"})


def update_new_service_definition(s_name, payload=None):
    # 更新定义
    md5 = hashlib.md5()  # 应用MD5算法
    data = json.dumps(payload)
    md5.update(data.encode('utf-8'))
    md5_sum = md5.hexdigest()
    payload.update({"md5": md5_sum})
    item_ori = mongo_consul.find_one({"ds": 2, "Name": s_name})
    md5_list = []
    definitions = []
    if item_ori:
        md5_list = item_ori["md5_list"]
        definitions = item_ori["definitions"]

    if md5_sum not in md5_list:
        md5_list.append(md5_sum)
        definitions.append(payload)
        item = {"ds": 2,
                "definitions": definitions,
                "md5_list": md5_list,
                "Name": s_name,
                "latest_MD5": md5_sum}
        mongo_consul.update_insert_one_by_pk_sk(item, pk={"ds": 2, "Name": s_name},
                                                sk={"$set": {"Status": "Changed"},
                                             "$set_if_not": {"Status": "New"}})
    else:
        consul_logger.info("reset order ...")
        consul_logger.info(md5_sum)
        # 如果不是最近的，更新顺序
        if md5_list[-1] != md5_sum:
            md5_list.remove(md5_sum)
            md5_list.append(md5_sum)
            for d in definitions:
                consul_logger.info(json.dumps(d, indent=4))
                if d["md5"] == md5_sum:
                    definitions.remove(d)
                    definitions.append(d)

            del item_ori["_id"]
            mongo_consul.update_insert_one_by_pk_sk(item_ori, pk={"ds": 2, "Name": s_name},
                                                    sk={"$set": {"Status": "Changed"},
                                                 "$set_if_not": {"Status": "New"}})


def update_after_register(s_name, dc="dc1", payload=None):
    """
    仅更新被注册的服务
    并检查已注册的同名服务是否需要更新为New状态，或Changed状态
    :param request:
    :return:
    """
    update_new_service_definition(s_name, payload=payload)
    return update_new_service_data(s_name, dc=dc)


def update_after_deregister(s_name, n_succ, dc="dc1"):
    update_de_service_data(s_name, n_succ, dc=dc)


def update_after_deregister000(s_name, n_succ, dc="dc1"):
    """
    ???
    :param s_name:
    :param n_succ:
    :param dc:
    :return:
    """
    consul_logger.info("[update_after_deregister2] s_name: " + s_name)
    if s_name:
        mongo_consul.delete({"ds": 1, "Name": s_name})
    else:
        return

    consul_url, consul_token = get_consul_settings(dc=dc)
    headers = {"X-Consul-Token": consul_token}
    url_service = os.path.join(consul_url, "v1/health/service/{}?dc={}".format(s_name, dc))
    resp = requests.get(url_service, headers=headers)
    # consul_logger.info("resp.content")
    # consul_logger.info(resp.content)
    if resp.content == b'[]':
        consul_logger.info("is b []")
        mongo_consul.update_many(pk={"ds": 0, "Name": s_name},
                                 sk={"$set": {"Status": "Lost",
                                       "ChecksPassing": 0, "ChecksWarning": 0, "ChecksCritical": 0}})
    else:
        stat = "Changed -{}".format(n_succ) if n_succ > 0 else "OK"
        mongo_consul.update_many(pk={"ds": 0, "Name": s_name}, sk={"$set": {"Status": stat}})


@admin_auth
def api_update_after_deregister(request):
    """
    仅更新被注销的服务
    并检查已注册的同名服务是否需要更新为Lost状态，或Changed状态
    :param request:
    :return:
    """
    s_name = request.GET.get("s_name")
    dc = request.GET.get("dc") or "dc1"
    # consul_logger.info("s_name & dc")
    # consul_logger.info(s_name + " & " + dc)
    mongo_consul.delete({"ds": 1, "Name": s_name})
    consul_url, consul_token = get_consul_settings(dc=dc)
    headers = {"X-Consul-Token": consul_token}
    url_service = os.path.join(consul_url, "v1/health/service/{}?dc={}".format(s_name, dc))
    resp = requests.get(url_service, headers=headers)
    # consul_logger.info("resp.content")
    # consul_logger.info(resp.content)
    if resp.content == b'[]':
        consul_logger.info("is b []")
        mongo_consul.update_many(pk={"ds": 0, "Name": s_name},
                                 sk={"$set": {"Status": "Lost",
                                              "ChecksPassing": 0, "ChecksWarning": 0, "ChecksCritical": 0}})
    else:
        mongo_consul.update_many(pk={"ds": 0, "Name": s_name}, sk={"$set": {"Status": "Changed"}})
        # todo

    return JsonResponse({"code": 200, "msg": "update_after_deregister ok"})


@admin_auth
def api_update_consul_data(request):
    """
    涉及两个视图的数据，一个是 应注册的， 一个是 实际注册的
    ，更新实际注册的，并对比标记 应注册的 丢失与否
    :param request:
    :return:
    """
    # 获取更新前的数据，以作对比
    # service_data0, count = mongo.find({"ds": 0})

    # 获取最新数据，对比，标记状态
    dc = request.GET.get("dc") or "dc1"
    consul_url, consul_token = get_consul_settings(dc=dc)
    headers = {"X-Consul-Token": consul_token}
    url_services = os.path.join(consul_url, "v1/internal/ui/services?dc={}".format(dc))
    consul_logger.info("url:")
    consul_logger.info(url_services)
    resp = requests.get(url_services, headers=headers)
    if 200 == resp.status_code:
        c_data = json.loads(resp.content)
        # mongo.insert_many(c_data)
        # 更新（包括新增）
        for c in c_data:
            c["ds"] = 1
            # mongo.update_insert_one_by_pk_sk(c, pk=["ds", "Name"])
        mongo_consul.delete({"ds": 1})
        mongo_consul.insert_many(c_data)

        # 标记已注册的同名service为正常, 不存在该已注册项则新增一条已注册, 如果存在多余未能匹配的则标记为Lost
        mongo_consul.update_many(pk={"ds": 0}, sk={"$set": {"Status": "Lost",
                                                     "ChecksPassing": 0, "ChecksWarning": 0, "ChecksCritical": 0}})
        for c in c_data:
            c["ds"] = 0
            del c["_id"]
            mongo_consul.update_insert_one_by_pk_sk(c, pk=["ds", "Name"],
                                                    sk={"$set": {"Status": "OK"},
                                                 "$set_if_not": {"Status": "New"}})
        return JsonResponse({"code": 200, "msg": "更新完毕"})
    else:
        return JsonResponse({"code": 500, "msg": "更新失败"})


@admin_auth
def get_service_definition(request):
    consul_logger.info("[get_service_definition] ...")
    if request.method == 'GET':
        s_name = request.GET.get('s_name')
        s_id = request.GET.get('s_id')
    if request.method == 'POST':
        s_name = request.POST.get('s_name')
        s_id = request.POST.get('s_id')
    # res = mongo.find({"Name": s_name, "ds": 2, "definitions": {"ID": s_id}})
    consul_logger.info("s_name: {}  s_id: {} ".format(s_name, s_id))
    res = mongo_consul.find_one({"Name": s_name, "ds": 2})
    if res and "definitions" in res:
        if s_id:
            all_def = []
            for r in res["definitions"]:
                if r["ID"] == s_id:
                    all_def.append(r)
        else:
            all_def = res["definitions"]
        consul_logger.info(json.dumps(all_def))
        return JsonResponse({'code': 200, 'data': all_def, 'msg': u'获取成功'}, encoder=JSONEncoder)
    else:
        consul_logger.info("no definition ...")
        return JsonResponse({'code': 500, 'data': [], 'msg': 'no definition'}, encoder=JSONEncoder)


@admin_auth
def get_service_info(request):
    """
    前端分页即可
    :param request:
    :return:
    """
    consul_logger.info("[get_service_info]")
    if request.method == 'GET':
        s_name = request.GET.get('s_name')
        dc = request.GET.get('dc') or "dc1"
    if request.method == 'POST':
        s_name = request.POST.get('s_name')
        dc = request.POST.get('dc') or "dc1"
    consul_logger.info("s_name={}, dc ={}".format(s_name, dc))

    consul_url, consul_token = get_consul_settings(dc=dc)
    headers = {"X-Consul-Token": consul_token}
    url_service = os.path.join(consul_url, "v1/health/service/{}?dc={}".format(s_name, dc))
    resp = requests.get(url_service, headers=headers)

    consul_logger.info("[get_service_info] resp code:" + str(resp.status_code))
    if 200 == resp.status_code:
        c_data = json.loads(resp.content)
        consul_logger.info("c_data")
        consul_logger.info(c_data)
        # get status
        node_check_ok = 1
        node_check_bad = 0
        service_check_ok = 0
        service_check_bad = 0
        # total_node_check = 1
        # total_service_check = 0
        for c in c_data:
            if "Checks" in c:
                if len(c["Checks"]) >= 1:
                    node_check_ok = 1 if c["Checks"][0]["Status"] == "passing" else 0
                    node_check_bad = 1 if c["Checks"][0]["Status"] != "passing" else 0
                if len(c["Checks"]) == 2:
                    service_check_ok = 1 if c["Checks"][1]["Status"] == "passing" else 0
                    service_check_bad = 1 if c["Checks"][1]["Status"] != "passing" else 0
            c["Status"] = {
                "NodeCheckPassing": node_check_ok,
                "NodeCheckNotPassing": node_check_bad,
                "ServiceCheckPassing": service_check_ok,
                "ServiceCheckNotPassing": service_check_bad
            }
            # total_node_check += node_check
            # total_service_check += service_check
        # c_data.append({"TotalNodeCheck": total_node_check})
        # c_data.append({"TotalServiceCheck": total_service_check})
        return JsonResponse({'code': 200, 'data': c_data, 'msg': u'获取成功'}, encoder=JSONEncoder)
    else:
        return JsonResponse({'code': 500, 'data': None, 'msg': u'获取失败，{}'.format(resp.content)})


@admin_auth
def del_service_definition(request):
    try:
        consul_logger.info("del_service_definition")
        s_name = None
        md5 = None
        s_id = None
        if request.method == "POST":
            s_id = request.POST.get('s_id')
            s_name = request.POST.get('s_name')
            md5 = request.POST.get('md5')
        if request.method == "GET":
            s_id = request.GET.get('s_id')
            s_name = request.GET.get('s_name')
            md5 = request.GET.get('md5')

        if not s_name:
            return JsonResponse({'code': 500, 'msg': u'参数错误'})

        res = mongo_consul.find_one({"ds": 2, "Name": s_name})
        if md5:
            md5_list = res["md5_list"]
            if md5 in md5_list:
                md5_list.remove(md5)

                definitions = res["definitions"]
                for d in definitions:
                    if d.get("md5") == md5:
                        definitions.remove(d)
            del res["_id"]
            mongo_consul.update_insert_one_by_pk_sk(res, pk={"ds": 2, "Name": s_name},
                                                    sk={"$set": {"Status": "Changed"},
                                                 "$set_if_not": {"Status": "New"}})
        elif s_id:
            definitions = res["definitions"]
            md5_list = res["md5_list"]
            for d in definitions:
                if d.get("ID") == s_id:
                    definitions.remove(d)
                    md5_list.remove(d.get("md5"))
        else:
            mongo_consul.delete({"ds": 2, "Name": s_name})
        return JsonResponse({'code': 200, 'msg': 'OK'})
    except Exception as e:
        consul_logger.info(str(e))
        return JsonResponse({'code': 500, 'msg': 'error'})


@admin_auth
def deregister_service(request):
    consul_logger.info("[deregister_service]")
    if request.method == "POST":
        s_id = request.POST.get('s_id')
        s_name = request.POST.get('s_name')
        ds = int(request.POST.get('ds') or "1")
    if request.method == "GET":
        s_id = request.GET.get('s_id')
        s_name = request.GET.get('s_name')
        ds = int(request.GET.get('ds') or "1")
    dc = request.GET.get('dc') or "dc1"
    headers = {
        "X-Consul-Token": "05h6bKqqscrkzAbKV96CPujD4GGKOBED"
    }

    if 0 == ds:
        # 删除记录，一个服务(Name)一个记录，不涉及ID
        consul_logger.info("----------------------------001")
        if not s_name:
            return JsonResponse({'code': 500, 'msg': u'参数错误'})
        else:
            res = mongo_consul.delete({"ds": 0, "Name": s_name})
            return JsonResponse({'code': 200,
                                 'msg': u'共删除了{}条记录<br>Name: {}'.format(
                                     res.deleted_count, s_name)}, encoder=JSONEncoder)

    consul_url, consul_token = get_consul_settings(dc=dc)
    headers = {"X-Consul-Token": consul_token}
    url_tmpl = os.path.join(consul_url, "v1/agent/service/deregister/{id}")
    if s_id:
        consul_logger.info("----------------------------002")
        resp = requests.put(url_tmpl.format(id=s_id), headers=headers)
        if 200 == resp.status_code:
            update_after_deregister(s_name, n_succ=1, dc=dc)
            return JsonResponse({'code': 200, 'msg': u'注销成功'}, encoder=JSONEncoder)
        else:
            update_after_deregister(s_name, n_succ=0, dc=dc)
            return JsonResponse({'code': 500, 'msg': u'注销失败，{}'.format(resp.content)})
    elif s_name:
        consul_logger.info("----------------------------003")
        s_ids = []
        res = get_service_info(request)
        resp = json.loads(res.content)
        # consul_logger.info(json.dumps(resp, indent=4))
        if resp["code"] == 200:
            consul_logger.info("200 ...")
            for c in resp["data"]:
                consul_logger.info("for c: {}".format(json.dumps(c)))
                s_ids.append(c["Service"]["ID"])

        consul_logger.info("s_ids is:")
        consul_logger.info(", ".join(s_ids))
        is_all_succ = True
        msg = []
        id_succ = []
        id_failed = []
        for id in s_ids:
            resp = requests.put(url_tmpl.format(id=id), headers=headers)
            if resp.status_code != 200:
                is_all_succ = False
                id_failed.append(id)
                msg.append("id: {} failed".format(id))
            else:
                id_succ.append(id)
                msg.append("id: {} succeed".format(id))
        update_after_deregister(s_name, n_succ=len(id_succ), dc=dc)
        if is_all_succ:
            mongo_consul.delete({"ds": 1, "Name": s_name})
            return JsonResponse({'code': 200, 'msg': u'注销成功，并已删除{}的记录'.format(s_name)}, encoder=JSONEncoder)
        else:
            return JsonResponse({'code': 500, 'msg': "<br>".join(msg)})
