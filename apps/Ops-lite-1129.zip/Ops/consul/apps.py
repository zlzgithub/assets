from django.apps import AppConfig


class ConsulConfig(AppConfig):
    name = 'consul'
